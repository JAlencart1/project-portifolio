import { Container, Row, Col, Tab, Nav } from "react-bootstrap";
import { ProjectCard } from "./ProjectCard";
import projImg1 from "../assets/img/project1.1.png";
import projImg2 from "../assets/img/project.1.2.png";
import projImg3 from "../assets/img/project1.3.png";
import colorSharp2 from "../assets/img/color-sharp2.png";
import 'animate.css';
import TrackVisibility from 'react-on-screen';

export const Projects = () => {

  const projects = [
    {
      title: "Mensagens",
      description: "Mensagens com SQS",
      imgUrl: projImg1,
    },
    {
      title: "System design",
      description: "Design & Development",
      imgUrl: projImg2,
    },
    {
      title: "Em breve",
      description: "Em desenvolvimento",
      imgUrl: projImg3,
    },
 
  ];

  return (
    <section className="project" id="project">
      <Container>
        <Row>
          <Col size={12}>
            <TrackVisibility>
              {({ isVisible }) =>
              <div className={isVisible ? "animate__animated animate__fadeIn": ""}>
                <h2>Projetos</h2>
                <Tab.Container id="projects-tabs" defaultActiveKey="first">
                  <Nav variant="pills" className="nav-pills mb-5 justify-content-center align-items-center" id="pills-tab">
                    <Nav.Item href="https://github.com/JAlencart1/app-SQS">
                      <Nav.Link eventKey="first">Tab 1</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="second">Tab 2</Nav.Link>
                    </Nav.Item>
                    <Nav.Item>
                      <Nav.Link eventKey="third">Tab 3</Nav.Link>
                    </Nav.Item>
                  </Nav>
                  <Tab.Content id="slideInUp" className={isVisible ? "animate__animated animate__slideInUp" : ""}>
                    <Tab.Pane eventKey="first">
                      <Row>
                        {
                          projects.map((project, index) => {
                            return (
                              <ProjectCard
                                key={index}
                                {...project}
                                />
                            )
                          })
                        }
                      </Row>
                    </Tab.Pane>
                    <Tab.Pane eventKey="section">
                      <p>O uso do UI e UX Design é essencial para gerar valor e promover a melhor experiência de usuário em seus produtos e/ou serviços. Para isso, é preciso ter conhecimento pleno de quem são os seus clientes, entender como ele se mostra diante de sua empresa, suas expectativas, entre outros fatores relevantes.</p>
                    </Tab.Pane>
                    <Tab.Pane eventKey="third">
                      <p>O uso do UI e UX Design é essencial para gerar valor e promover a melhor experiência de usuário em seus produtos e/ou serviços. Para isso, é preciso ter conhecimento pleno de quem são os seus clientes, entender como ele se mostra diante de sua empresa, suas expectativas, entre outros fatores relevantes.</p>
                    </Tab.Pane>
                  </Tab.Content>
                </Tab.Container>
              </div>}
            </TrackVisibility>
          </Col>
        </Row>
      </Container>
      <img className="background-image-right" src={colorSharp2}></img>
    </section>
  )
}
